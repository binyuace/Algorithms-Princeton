///////////////////////////////////////////////////////////////////////
// Copyright (C) Bin Yu
// All rights reserved
///////////////////////////////////////////////////////////////////////

import edu.princeton.cs.algs4.StdRandom;      
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats { 
    private Percolation perc;
    private double[] threshold;
    public PercolationStats(int n, int trials) { 
        // perform trials independent experiments on an n-by-n grid
        threshold = new double[trials];
        for (int i = 0; i < trials; i++) {
            perc = new Percolation(n);
            while (!perc.percolates()) {
                int a = StdRandom.uniform(1, n+1);
                int b = StdRandom.uniform(1, n+1);
                perc.open(a, b);
            }
            threshold[i] = (perc.numberOfOpenSites()+0.0)/(n*n);
        }
    }
    public double mean() {
        // sample mean of percolation threshold
        double ans = StdStats.mean(threshold);
        return ans;
    }
    public double stddev() {
        // sample standard deviation of percolation threshold 
        double ans = StdStats.stddev(threshold);
        return ans;
    }
    public double confidenceLo() {
        // low  endpoint of 95% confidence interval
        return mean() - (1.96*stddev())/threshold.length;
    }
    public double confidenceHi() {
        // high endpoint of 95% confidence interval 
        return mean() + (1.96*stddev())/threshold.length;
    }
    public static void main(String[] args) {
        // test client (described below)
        int n = Integer.parseInt(args[0]);
        int trials = Integer.parseInt(args[1]);
        PercolationStats percstats = new PercolationStats(n, trials);
        System.out.println("mean = "+ percstats.mean());
        System.out.println("stddev = "+ percstats.stddev());
        System.out.println("95% confidence interval = ["+ percstats.confidenceLo()+", "+ percstats.confidenceHi()+"]");        
    }
} 